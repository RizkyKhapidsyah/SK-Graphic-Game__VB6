November 2/99:

I have added the tabctl32.ocx file used by the program to create the
tab control in frmResearch - several people have found that they do
not have the latest version of this ocx, so I am including it here if
needed. 

Just copy it to your windows\system directory - it should self-register.
If not, use regsvr32.exe to register it.

If you have any problems, email me at gordons@interlog.com